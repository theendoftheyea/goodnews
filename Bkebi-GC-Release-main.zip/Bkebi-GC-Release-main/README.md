<div align=center>
<img src="https://github.com/Bkebi-Group/Bkebi-GC-Release/raw/main/.github/logo.svg" width="520"/>
</div>

<p align="center">
	<a href="https://github.com/Bkebi-Group/Bkebi-GC-Release/releases/latest"><img src="https://img.shields.io/github/v/release/Bkebi-Group/Bkebi-GC-Release?style=for-the-badge"></a>
	<a href="https://github.com/Bkebi-Group/Bkebi-GC-Release/releases"><img src="https://img.shields.io/github/downloads/Bkebi-Group/Bkebi-GC-Release/total.svg?style=for-the-badge"></a>
	<a href="https://discord.gg/bkebi"><img src="https://img.shields.io/discord/1026295403282436097?label=Discord&logo=discord&style=for-the-badge&color=blueviolet"></a>
</p>


# Bkebi-GC Release

[Download **newest** release](https://github.com/Bkebi-Group/Bkebi-GC-Release/releases/latest)

**[Join our discord!](https://discord.gg/bkebi)**
